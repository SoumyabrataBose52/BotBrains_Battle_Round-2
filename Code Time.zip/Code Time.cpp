#include <Servo.h>
#include <avr/sleep.h> // Added to include sleep mode functions

const int soilMoisturePin = A0;
const int potPin = A1; //potentiometer
const int pumpPin = 9;
const int ledPin = 13; //LED feedback
const int buzzerPin = 8; //buzzer feedback
const int buttonPin = 2; //wake-up button
Servo servoMotor;

void setup() {
  pinMode(soilMoisturePin, INPUT);
  pinMode(potPin, INPUT); //potentiometer
  pinMode(pumpPin, OUTPUT);
  pinMode(ledPin, OUTPUT); //LED feedback
  pinMode(buzzerPin, OUTPUT); //buzzer feedback
  pinMode(buttonPin, INPUT_PULLUP); //wake-up button
  servoMotor.attach(10);

  attachInterrupt(digitalPinToInterrupt(buttonPin), wakeUp, LOW); // Added interrupt for wake-up button
}

void loop() {
  // Set the system to sleep mode to save power
  set_sleep_mode(SLEEP_MODE_PWR_DOWN);
  sleep_enable();
  sleep_cpu();

  // System wakes up
  sleep_disable();

  // Read the potentiometer to set the custom soil moisture threshold
  int potVal = analogRead(potPin); //read potentiometer value
  int moistThold = map(potVal, 0, 1023, 0, 1023); //map potentiometer value to threshold

  // Read the soil moisture level
  int soilMoisture = analogRead(soilMoisturePin);

  // Check if soil moisture is below the threshold
  if (soilMoisture < moistThold) { // Changed to use custom threshold
    digitalWrite(pumpPin, HIGH);
    servoMotor.write(90);
    feedback(true); //provide feedback when watering starts
    delay(5000); // Watering duration
    digitalWrite(pumpPin, LOW);
    servoMotor.write(0);
    feedback(false); //provide feedback when watering stops
  }

  delay(1000); // Check soil moisture every second
}

// feedback function for buzzer and LED
void feedback(bool watering) {
  if (watering) {
    tone(buzzerPin, 1000, 500); // Buzzer beeps for 500ms
    digitalWrite(ledPin, HIGH);
    delay(500);
    digitalWrite(ledPin, LOW);
  } else {
    tone(buzzerPin, 500, 500); // Buzzer beeps for 500ms
    digitalWrite(ledPin, HIGH);
    delay(500);
    digitalWrite(ledPin, LOW);
  }
}

// wakeUp function for interrupt
void wakeUp() {
  return;
}
